import './App.css';
import UserList from "./components/Users/UserList";
import AddUsers from './components/Users/AddUsers';
import { useState } from 'react';

function App() {

  const [usersList, setUserList] = useState([]);
  const addUserHandler = (uName, uAge) => {
    setUserList((prevUserList) => {
      return [...prevUserList, { id: Math.random().toString(), name: uName, age: uAge }];
    });
  }

  return (
    <div>
      <AddUsers onAddUser={addUserHandler} />
      <UserList users={usersList} />
    </div>
  );
}

export default App;
