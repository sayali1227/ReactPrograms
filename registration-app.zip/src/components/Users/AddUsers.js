import React, { useState } from "react";
import Card from "../UI/Card";
import classes from "./AddUsers.module.css";
import Button from "../UI/Button";
import ErrorModel from "../UI/ErrorModel";

const AddUsers = (props) => {

    const [enteredUserName, setEnteredUername] = useState('');
    const [enteredAge, setEnteredAge] = useState('');
    const [error, setErrorMsg] = useState();

    const addUserHandler = (event) => {
        event.preventDefault();

        if (enteredAge.trim().length === 0 || enteredUserName.trim().length === 0) {
            setErrorMsg({
                title: "Invalid Inputs",
                message: "Please enter valid username and age (non-empty values)."
            });
            return;
        }
        if (+enteredAge < 1) {
            setErrorMsg({
                title: "Invalid age",
                message: "Please enter valid age (> 0)."
            });
            return;
        }

        props.onAddUser(enteredUserName, enteredAge);
        setEnteredAge('');
        setEnteredUername('');
    };

    const usernameChangeHandler = (event) => {
        setEnteredUername(event.target.value);
    };

    const ageChangeHandler = (event) => {
        setEnteredAge(event.target.value);
    };

    const errorHandler = () => {
        setErrorMsg(null);
    }

    return (
        <div>
            {error && <ErrorModel title={error.title} message={error.message} onConfirm={errorHandler} />}
            <Card className={classes.input}>
                <form onSubmit={addUserHandler}>
                    <label htmlFor="usename">Username</label>
                    <input id="username" type="text" onChange={usernameChangeHandler} value={enteredUserName} />
                    <label htmlFor="age">Age (Years)</label>
                    <input id="age" type="number" onChange={ageChangeHandler} value={enteredAge} />
                    <Button type="submit">Add user</Button>
                </form>

            </Card>
        </div>
    )

}

export default AddUsers;